// environment.ts
export const environment = {
    production: false,
    formId: '',
    apiKey: '',
    adminPass: ''
  };